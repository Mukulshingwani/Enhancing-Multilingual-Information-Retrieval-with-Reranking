This zip contains an extension (i.e., more languages) of the STS 2017 evaluation dataset:
http://ixa2.si.ehu.es/stswiki/index.php/Main_Page



The following lanugages pairs are included:
ar-ar: Original file from STS2017
en-ar: Original file from STS2017
en-en: Original file from STS2017
en-tr: Original file from STS2017
es-en: Original file from STS2017
es-es: Original file from STS2017

Newly added files:
en-de: The STS17 en-en file was used and the second sentence was translated to German by a native speaker
fr-en: The STS17 en-en file was used and the first sentence was translated to French using Google Translate
it-en: The STS17 en-en file was used and the first sentence was translated to Italian using Google Translate
nl-en: The STS17 en-en file was used and the first sentence was translated to Dutch using Google Translate


This file is used (besides others) for evaluating multilingual sentence representation models:
https://github.com/UKPLab/sentence-transformers
